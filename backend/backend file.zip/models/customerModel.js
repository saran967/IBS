import mongoose from "mongoose";

const companySchema = new mongoose.Schema({
  companyName: {
    type: String,
    required: true,
  },
  companyLocation: {
    type: String,
  },
  companyEmail: {
    type: String,
  },
  companyPhoneNumber: {
    type: String,
  },
  gstNumber: {
    type: String,
  },
  companyQuantity: {
    type: Number,
  },
});

const customerSchema = new mongoose.Schema(
  {
    customerType: {
      type: String,
      enum: ["B2C", "B2B", "agent"],
      required: true,
    },
    customerName: {
      en: { type: String, required: true },
      ta: { type: String },
    },

    fcmToken: {
      type: String,
      default: null,
    },

    totalIncentive: { type: Number, default: 0 },

    mobileNumber: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    email: {
      type: String,
      unique: true,
      sparse: true,
    },

    isMobileVerified: {
      type: Boolean,
      default: function () {
        return this.customerType !== "B2B";
      },
    },

    lastOtpSentAt: {
      type: Date,
      default: null,
    },

    password: {
      type: String,
    },
    address: {
      en: { type: String },
      ta: { type: String },
    },
    shippingAddress: {
      en: { type: String },
      ta: { type: String },
    },
    city: {
      type: String,
    },
    state: {
      type: String,
    },
    pincode: {
      type: String,
    },
   customerCode: {
  type: String,
  unique: true,
},

openingBalance: {
  type: Number,
  default: 0,
},

creditLimit: {
  type: Number,
  default: 100000,
},

dueDays: {
  type: Number,
  default: 15,
},


    companies: [companySchema],

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  { timestamps: true }
);

export default mongoose.model("Customer", customerSchema);
