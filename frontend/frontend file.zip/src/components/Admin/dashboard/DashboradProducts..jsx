import {
  Paper,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Stack,
  Button,
  Box,
  Chip,
  IconButton,
  TableContainer,
} from "@mui/material";
import { MdWarning, MdCheckCircle, MdInventory } from "react-icons/md";

export default function DashboardProducts({ products = [] }) {
  const getStockStatus = (stock, reorder) => {
    if (stock == 0)
      return { label: "Out of Stock", color: "error", icon: <MdWarning /> };

    if (stock <= 10)
      return { label: "Low Stock", color: "warning", icon: <MdWarning /> };

    return { label: "In Stock", color: "success", icon: <MdCheckCircle /> };
  };

  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 3,
        border: "1px solid",
        borderColor: "divider",
      }}
    >
      <Stack
        direction={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "flex-start", sm: "center" }}
        spacing={2}
        sx={{ mb: 3 }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              color: "#fff",
            }}
          >
            <MdInventory size={24} />
          </Box>

          <Box>
            <Typography sx={{ fontWeight: 700, fontSize: "1.125rem" }}>
              Product Inventory
            </Typography>
            <Typography variant="caption" sx={{ color: "text.secondary" }}>
              Current stock levels and status
            </Typography>
          </Box>
        </Box>

        {/*  */}
      </Stack>

      <TableContainer sx={{ maxHeight: 500 }}>
        <Table size="small" stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 600, bgcolor: "background.paper" }}>
                Code
              </TableCell>
              <TableCell sx={{ fontWeight: 600, bgcolor: "background.paper" }}>
                Product Name
              </TableCell>
              <TableCell
                align="left"
                sx={{ fontWeight: 600, bgcolor: "background.paper" }}
              >
                Stock Qty
              </TableCell>

              <TableCell sx={{ fontWeight: 600, bgcolor: "background.paper" }}>
                Status
              </TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} align="center" sx={{ py: 4 }}>
                  <Typography variant="body2" color="text.secondary">
                    No product data available
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              [...products]
                .sort((a, b) => (b.totalStock ?? 0) - (a.totalStock ?? 0)) // High → Low
                .slice(0, 10) // Top 10
                .map((p) => {
                  const status = getStockStatus(p.totalStock, p.reorder);

                  const productName =
                    typeof p.name === "object" ? p.name?.en : p.name;

                  return (
                    <TableRow
                      key={p._id}
                      hover
                      sx={{
                        "&:last-child td": { border: 0 },
                        cursor: "pointer",
                        transition: "all 0.2s ease",
                        bgcolor:
                          p.totalStock === 0
                            ? "#fef9c3"
                            : p.totalStock <= 10
                              ? "#fef9c3"
                              : "inherit",

                        "&:hover": {
                          bgcolor:
                            p.totalStock === 0
                              ? "#fecaca"
                              : p.totalStock <= 10
                                ? "#fde68a"
                                : "#f3f4f6",
                        },
                      }}
                    >
                      <TableCell
                        sx={{ fontWeight: 500, fontFamily: "monospace" }}
                      >
                        {p.productCode || p._id}
                      </TableCell>

                      <TableCell sx={{ fontWeight: 500 }}>
                        {productName || "N/A"}
                      </TableCell>

                      <TableCell align="left" sx={{ fontWeight: 600 }}>
                        {p.totalStock ?? "-"}
                      </TableCell>

                      <TableCell>
                        <Chip
                          label={status.label}
                          size="small"
                          color={status.color}
                          icon={status.icon}
                          sx={{
                            fontSize: "0.7rem",
                            fontWeight: 600,
                            "& .MuiChip-icon": { fontSize: "0.9rem" },
                          }}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
