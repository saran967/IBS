import FinancialYear from "../models/FinancialYear.js";

const getActiveFinancialYear = async () => {
  const activeFY = await FinancialYear.findOne({ isActive: true });

  if (!activeFY) {
    throw new Error("No active financial year found.");
  }

  return activeFY;
};

export default getActiveFinancialYear;