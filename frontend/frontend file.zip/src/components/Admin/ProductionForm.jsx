// import React, { useState, useRef, useEffect } from "react";
// import {
//   Box,
//   TextField,
//   Button,
//   FormControlLabel,
//   Checkbox,
//   Grid,
// } from "@mui/material";
// import { toast } from "react-toastify";
// import JsBarcode from "jsbarcode";
// import customFetch from "../../utils/customFetch";

// const ProductForm = ({ refreshList, editProduct, clearEdit }) => {
//   const [formData, setFormData] = useState({
//     name_en: "",
//     name_ta: "",
//     category_en: "",
//     category_ta: "",
//     unit_en: "",
//     unit_ta: "",
//     productCode: "",
//     weight: "",
//     purchasePrice: "",
//     profitPercentage: "",
//     sellingPrice: "",
//     cgstPercentage: "",
//     sgstPercentage: "",
//     hsnCode: "",
//     allowRetail: false,

//     fssaiNumber: "",
//     packedDate: "",
//     useByDate: "",
//     mrp: "",
//   });

//   const inputRefs = useRef([]);
//   const svgRef = useRef(null);

//   useEffect(() => {
//     if (editProduct) {
//       setFormData({
//         name_en: editProduct.name?.en || "",
//         name_ta: editProduct.name?.ta || "",
//         category_en: editProduct.category?.en || "",
//         category_ta: editProduct.category?.ta || "",
//         unit_en: editProduct.unit?.en || "",
//         unit_ta: editProduct.unit?.ta || "",
//         productCode: editProduct.productCode || "",
//         weight: editProduct.weight || "",
//         purchasePrice: editProduct.purchasePrice || "",
//         profitPercentage: editProduct.profitPercentage || "",
//         sellingPrice: editProduct.sellingPrice || "",
//         cgstPercentage: editProduct.cgstPercentage || "",
//         sgstPercentage: editProduct.sgstPercentage || "",
//         allowRetail: editProduct.allowRetail ?? false,
//         hsnCode: editProduct.allowRetail || "",
//         fssaiNumber: editProduct.fssaiNumber || "",
//         packedDate: editProduct.packedDate || "",
//         useByDate: editProduct.useByDate || "",
//         mrp: editProduct.mrp || "",
//       });
//     }
//   }, [editProduct]);

//   const handleChange = (e) => {
//     const { name, value } = e.target;

//     const numberFields = [
//       "weight",
//       "purchasePrice",
//       "profitPercentage",
//       "sellingPrice",
//       "sellingPrice",
//       "gstPercentage",
//       "fssaiNumber",
//       "mrp",
//     ];

//     // Allow text in name/category/unit fields
//     if (numberFields.includes(name)) {
//       if (value !== "" && !/^\d*\.?\d*$/.test(value)) return;
//     }

//     setFormData((prev) => {
//       let updated = { ...prev, [name]: value };

//       const purchase = parseFloat(updated.purchasePrice || 0);

//       // CASE 1 → Profit% entered → calc selling price
//       if (name === "profitPercentage") {
//         const profit = parseFloat(value || 0);
//         if (purchase > 0) {
//           updated.sellingPrice = (purchase + (purchase * profit) / 100).toFixed(
//             2
//           );
//         }
//       }

//       // CASE 2 → Selling price entered → calc profit %
//       if (name === "sellingPrice") {
//         const selling = parseFloat(value || 0);
//         if (purchase > 0) {
//           updated.profitPercentage = (
//             ((selling - purchase) / purchase) *
//             100
//           ).toFixed(2);
//         }
//       }

//       return updated;
//     });
//   };

//   const handleKeyDown = (e, index) => {
//     if (e.key === "Enter") {
//       e.preventDefault();
//       const next = inputRefs.current[index + 1];
//       if (next) next.focus();
//       else handleSubmit();
//     }
//   };

//   const handleSubmit = async () => {
//     try {
//       if (!formData.name_en.trim()) return toast.error("English name required");
//       if (!formData.productCode.trim())
//         return toast.error("Product code required");

//       const payload = {
//         name: { en: formData.name_en, ta: formData.name_ta },
//         category: { en: formData.category_en, ta: formData.category_ta },
//         unit: { en: formData.unit_en, ta: formData.unit_ta },
//         productCode: formData.productCode,
//         weight: formData.weight ? parseFloat(formData.weight) : 0,
//         purchasePrice: Number(formData.purchasePrice || 0),
//         profitPercentage: Number(formData.profitPercentage || 0),
//         sellingPrice: Number(formData.sellingPrice || 0),
//         cgstPercentage: Number(formData.cgstPercentage || 0),
//         sgstPercentage: Number(formData.sgstPercentage || 0),
//         hsnCode: formData.hsnCode,
//         allowRetail: formData.allowRetail,

//         fssaiNumber: Number(formData.fssaiNumber || 0),
//         packedDate: formData.packedDate,
//         useByDate: formData.useByDate,
//         mrp: Number(formData.mrp || 0),
//       };

//       if (editProduct) {
//         await customFetch.patch(`/product/${editProduct._id}`, payload);
//         toast.success("Product updated successfully");
//         clearEdit();
//       } else {
//         await customFetch.post("/product", payload);
//         toast.success("Product added successfully");
//       }

//       refreshList();
//       setFormData({
//         name_en: "",
//         name_ta: "",
//         category_en: "",
//         category_ta: "",
//         unit_en: "",
//         unit_ta: "",
//         productCode: "",
//         weight: "",
//         purchasePrice: "",
//         profitPercentage: "",
//         cgstPercentage: "",
//         sgstPercentage: "",
//         allowRetail: false,

//         fssaiNumber: "",
//         packedDate: "",
//         useByDate: "",
//         mrp: "",
//       });
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Error saving product");
//     }
//   };

//   useEffect(() => {
//     if (formData.productCode && svgRef.current) {
//       svgRef.current.innerHTML = "";
//       JsBarcode(svgRef.current, formData.productCode, {
//         format: "CODE128",
//         width: 2,
//         height: 40,
//         displayValue: true,
//       });
//     }
//   }, [formData.productCode]);

//   const fields = [
//     { label: "Name (EN)", name: "name_en" },
//     { label: "Name (TA)", name: "name_ta" },
//     { label: "Category (EN)", name: "category_en" },
//     { label: "Category (TA)", name: "category_ta" },
//     { label: "Unit (EN)", name: "unit_en" },
//     { label: "Unit (TA)", name: "unit_ta" },
//     { label: "Weight (kg)", name: "weight" },
//     { label: "Purchase Price", name: "purchasePrice" },
//     { label: "Profit %", name: "profitPercentage" },
//     { label: "Selling Price", name: "sellingPrice" },

//     { label: "Fssai Number", name: "fssaiNumber" },
//     { label: "Packed Date", name: "packedDate" },
//     { label: "Use By Date", name: "useByDate" },
//     { label: "MRP", name: "mrp" },

//     { label: "CGST %", name: "cgstPercentage" },
//     { label: "SGST %", name: "sgstPercentage" },
//     { label: "HSN Code", name: "hsnCode" },

//     { label: "Product Code", name: "productCode" },
//   ];

//   return (
//     <Box sx={{ mb: 2, p: 2, bgcolor: "#fafafa", borderRadius: 2 }}>
//       {/* ---------- ROW 1 : 5 COLUMNS ---------- */}
//       {/* <Grid container spacing={2} mb={2}>
//       {[
//         { label: "Name (EN)", name: "name_en" },
//         { label: "Name (TA)", name: "name_ta" },
//         { label: "Category (EN)", name: "category_en" },
//         { label: "Category (TA)", name: "category_ta" },
//         { label: "Unit (EN)", name: "unit_en" },
//       ].map((f, i) => (
//         <Grid item xs={12} sm={6} md={2.4}
// key={f.name}>
//           <TextField
//             // sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
// fullWidth
//             size="small"
//             label={f.label}
//             name={f.name}
//             value={formData[f.name]}
//             onChange={handleChange}
//             inputRef={(el) => (inputRefs.current[i] = el)}
//           />
//         </Grid>
//       ))}
//     </Grid> */}

//       {/* ---------- ROW 2 : 5 COLUMNS ---------- */}
//       {/* <Grid container spacing={2} mb={2}>
//       {[
//         { label: "Unit (TA)", name: "unit_ta" },
//         { label: "Weight (kg)", name: "weight" },
//         { label: "Purchase Price", name: "purchasePrice" },
//         { label: "Profit %", name: "profitPercentage" },
//         { label: "Selling Price", name: "sellingPrice" },
//       ].map((f) => (
//         <Grid item xs={12} sm={6} md={2.4}
//  key={f.name}>
//           <TextField
//             // sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
// fullWidth
//             size="small"
//             label={f.label}
//             name={f.name}
//             value={formData[f.name]}
//             onChange={handleChange}
//           />
//         </Grid>
//       ))}
//     </Grid> */}

//       {/* ---------- ROW 3 : 4 COLUMNS ---------- */}
//       {/* <Grid container spacing={2} mb={2}>
//       {[
//         { label: "CGST %", name: "cgstPercentage" },
//         { label: "SGST %", name: "sgstPercentage" },
//         { label: "HSN Code", name: "hsnCode" },
//         { label: "Product Code", name: "productCode" },
//       ].map((f) => (
//         <Grid item xs={12} sm={6} md={3} key={f.name}>
//           <TextField
//           //  sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
// fullWidth
//             size="small"
//             label={f.label}
//             name={f.name}
//             value={formData[f.name]}
//             onChange={handleChange}
//           />
//         </Grid>
//       ))}
//     </Grid> */}

//       <div className="w-full overflow-x-auto">
//         <div
//           className="
//       grid gap-4
//       grid-cols-1
//       sm:grid-cols-[repeat(auto-fill,minmax(180px,1fr))]
//       md:min-w-max
//     "
//         >
//           {[
//             { label: "Name (EN)", name: "name_en" },
//             { label: "Name (TA)", name: "name_ta" },
//             { label: "Category (EN)", name: "category_en" },
//             { label: "Category (TA)", name: "category_ta" },
//             { label: "Unit (EN)", name: "unit_en" },
//             { label: "Unit (TA)", name: "unit_ta" },
//             { label: "Weight (kg)", name: "weight" },
//             { label: "Purchase Price", name: "purchasePrice" },
//             { label: "Profit %", name: "profitPercentage" },
//             { label: "Selling Price", name: "sellingPrice" },
//             { label: "CGST %", name: "cgstPercentage" },
//             { label: "SGST %", name: "sgstPercentage" },
//             { label: "HSN Code", name: "hsnCode" },
//             { label: "Product Code", name: "productCode" },

//             { label: "Fssai Number", name: "fssaiNumber" },
//             { label: "Packed Date", name: "packedDate" },
//             { label: "Use By Date", name: "useByDate" },
//             { label: "MRP", name: "mrp" },
//           ].map((f, i) => (
//             <TextField
//               key={f.name}
//               fullWidth
//               size="small"
//               label={f.label}
//               name={f.name}
//               type={
//                 f.name === "packedDate" || f.name === "useByDate"
//                   ? "date"
//                   : "text"
//               }
//               value={formData[f.name]}
//               onChange={handleChange}
//               onKeyDown={(e) => handleKeyDown(e, i)} //  ADD THIS LINE
//               InputLabelProps={
//                 f.name === "packedDate" || f.name === "useByDate"
//                   ? { shrink: true }
//                   : undefined
//               }
//               inputRef={(el) => (inputRefs.current[i] = el)}
//             />
//           ))}
//         </div>
//       </div>

//       {/* ---------- CHECKBOX ---------- */}
//       <Grid container mb={2}>
//         <Grid item xs={12}>
//           <FormControlLabel
//             control={
//               <Checkbox
//                 checked={formData.allowRetail}
//                 onChange={(e) =>
//                   setFormData((prev) => ({
//                     ...prev,
//                     allowRetail: e.target.checked,
//                   }))
//                 }
//               />
//             }
//             label="Enable Retail Variants (SKU)"
//           />
//         </Grid>
//       </Grid>

//       {/* ---------- BUTTONS ---------- */}
//       <Grid container spacing={2}>
//         <Grid item xs={12} sm={4} md={2}>
//           <Button fullWidth variant="contained" onClick={handleSubmit}>
//             {editProduct ? "Update" : "Add"}
//           </Button>
//         </Grid>

//         {editProduct && (
//           <Grid item xs={12} sm={4} md={2}>
//             <Button
//               fullWidth
//               variant="outlined"
//               color="warning"
//               onClick={clearEdit}
//             >
//               Cancel
//             </Button>
//           </Grid>
//         )}
//       </Grid>

//       {/* ---------- BARCODE ---------- */}
//       {formData.productCode && (
//         <Box textAlign="center" mt={2}>
//           <svg ref={svgRef} />
//         </Box>
//       )}
//     </Box>
//   );
// };

// export default ProductForm;

import React, { useState, useRef, useEffect } from "react";
import {
  Box,
  TextField,
  Button,
  FormControlLabel,
  Checkbox,
  Grid,
  MenuItem,
} from "@mui/material";
import { toast } from "react-toastify";
import JsBarcode from "jsbarcode";
import customFetch from "../../utils/customFetch";

const ProductForm = ({ refreshList, editProduct, clearEdit }) => {
  const [formData, setFormData] = useState({
    name_en: "",
    name_ta: "",
    category_en: "",
    category_ta: "",
    unit_en: "",
    unit_ta: "",
    productCode: "",
    weight: "",
    purchasePrice: "",
    profitPercentage: "",
    sellingPrice: "",
    cgstPercentage: "",
    sgstPercentage: "",
    hsnCode: "",
    allowRetail: false,
    baseUnitType: "G",

    fssaiNumber: "",
    packedDate: "",
    useByDate: "",
    mrp: "",
  });

  const inputRefs = useRef([]);
  const svgRef = useRef(null);

  useEffect(() => {
    if (editProduct) {
      setFormData({
        name_en: editProduct.name?.en || "",
        name_ta: editProduct.name?.ta || "",
        category_en: editProduct.category?.en || "",
        category_ta: editProduct.category?.ta || "",
        unit_en: editProduct.unit?.en || "",
        unit_ta: editProduct.unit?.ta || "",
        productCode: editProduct.productCode || "",
        weight:
          editProduct.baseUnitType === "G" || editProduct.baseUnitType === "ML"
            ? editProduct.weight / 1000
            : editProduct.weight,
        purchasePrice: editProduct.purchasePrice || "",
        profitPercentage: editProduct.profitPercentage || "",
        sellingPrice: editProduct.sellingPrice || "",
        cgstPercentage: editProduct.cgstPercentage || "",
        sgstPercentage: editProduct.sgstPercentage || "",
        allowRetail: editProduct.allowRetail ?? false,
        hsnCode: editProduct.hsnCode || "",
        baseUnitType: editProduct.baseUnitType || "G",

        fssaiNumber: editProduct.fssaiNumber || "",
        packedDate: editProduct.packedDate || "",
        useByDate: editProduct.useByDate || "",
        mrp: editProduct.mrp || "",
      });
    }
  }, [editProduct]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    const numberFields = [
      "weight",
      "purchasePrice",
      "profitPercentage",
      "sellingPrice",
      "cgstPercentage",
      "sgstPercentage",
      "fssaiNumber",
      "mrp",
    ];

    // Allow text in name/category/unit fields
    if (numberFields.includes(name)) {
      if (value !== "" && !/^\d*\.?\d*$/.test(value)) return;
    }

    setFormData((prev) => {
      let updated = { ...prev, [name]: value };

      const purchase = parseFloat(updated.purchasePrice || 0);

      // CASE 1 → Profit% entered → calc selling price
      if (name === "profitPercentage") {
        const profit = parseFloat(value || 0);
        if (purchase > 0) {
          updated.sellingPrice = (purchase + (purchase * profit) / 100).toFixed(
            2,
          );
        }
      }

      // CASE 2 → Selling price entered → calc profit %
      if (name === "sellingPrice") {
        const selling = parseFloat(value || 0);
        if (purchase > 0) {
          updated.profitPercentage = (
            ((selling - purchase) / purchase) *
            100
          ).toFixed(2);
        }
      }

      return updated;
    });
  };

  const handleKeyDown = (e, index) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const next = inputRefs.current[index + 1];
      if (next) next.focus();
      else handleSubmit();
    }
  };

  const handleSubmit = async () => {
    try {
      if (!formData.name_en.trim()) return toast.error("English name required");
      if (!formData.productCode.trim())
        return toast.error("Product code required");
      let weight = Number(formData.weight || 0);

      // Convert display unit → base unit
      if (formData.baseUnitType === "G" || formData.baseUnitType === "ML") {
        weight = weight * 1000;
      }
      const payload = {
        name: { en: formData.name_en, ta: formData.name_ta },
        category: { en: formData.category_en, ta: formData.category_ta },
        unit: { en: formData.unit_en, ta: formData.unit_ta },
        productCode: formData.productCode,
        weight: weight,
        purchasePrice: Number(formData.purchasePrice || 0),
        profitPercentage: Number(formData.profitPercentage || 0),
        sellingPrice: Number(formData.sellingPrice || 0),
        cgstPercentage: Number(formData.cgstPercentage || 0),
        sgstPercentage: Number(formData.sgstPercentage || 0),
        hsnCode: formData.hsnCode,
        allowRetail: formData.allowRetail,
        baseUnitType: formData.baseUnitType,

        fssaiNumber: Number(formData.fssaiNumber || 0),
        packedDate: formData.packedDate,
        useByDate: formData.useByDate,
        mrp: Number(formData.mrp || 0),
      };

      if (editProduct) {
        await customFetch.patch(`/product/${editProduct._id}`, payload);
        toast.success("Product updated successfully");
        clearEdit();
      } else {
        await customFetch.post("/product", payload);
        toast.success("Product added successfully");
      }

      refreshList();
      setFormData({
        name_en: "",
        name_ta: "",
        category_en: "",
        category_ta: "",
        unit_en: "",
        unit_ta: "",
        productCode: "",
        weight: "",
        purchasePrice: "",
        profitPercentage: "",
        cgstPercentage: "",
        sgstPercentage: "",
        allowRetail: false,
        baseUnitType: "G",

        fssaiNumber: "",
        packedDate: "",
        useByDate: "",
        mrp: "",
      });
    } catch (err) {
      toast.error(err.response?.data?.message || "Error saving product");
    }
  };

  useEffect(() => {
    if (formData.productCode && svgRef.current) {
      svgRef.current.innerHTML = "";
      JsBarcode(svgRef.current, formData.productCode, {
        format: "CODE128",
        width: 2,
        height: 40,
        displayValue: true,
      });
    }
  }, [formData.productCode]);

  const fields = [
    { label: "Name (EN)", name: "name_en" },
    { label: "Name (TA)", name: "name_ta" },
    { label: "Category (EN)", name: "category_en" },
    { label: "Category (TA)", name: "category_ta" },
    { label: "Unit (EN)", name: "unit_en" },
    { label: "Unit (TA)", name: "unit_ta" },
    { label: "Base Unit Type (G/ML/PCS)", name: "baseUnitType" },
    { label: "Weight (kg)", name: "weight" },
    { label: "Purchase Price", name: "purchasePrice" },
    { label: "Profit %", name: "profitPercentage" },
    { label: "Selling Price", name: "sellingPrice" },

    { label: "Fssai Number", name: "fssaiNumber" },
    { label: "Packed Date", name: "packedDate" },
    { label: "Use By Date", name: "useByDate" },
    { label: "MRP", name: "mrp" },

    { label: "CGST %", name: "cgstPercentage" },
    { label: "SGST %", name: "sgstPercentage" },
    { label: "HSN Code", name: "hsnCode" },

    { label: "Product Code", name: "productCode" },
  ];

  return (
    <Box sx={{ mb: 2, p: 2, bgcolor: "#fafafa", borderRadius: 2 }}>
      {/* ---------- ROW 1 : 5 COLUMNS ---------- */}
      {/* <Grid container spacing={2} mb={2}>
      {[
        { label: "Name (EN)", name: "name_en" },
        { label: "Name (TA)", name: "name_ta" },
        { label: "Category (EN)", name: "category_en" },
        { label: "Category (TA)", name: "category_ta" },
        { label: "Unit (EN)", name: "unit_en" },
      ].map((f, i) => (
        <Grid item xs={12} sm={6} md={2.4}
key={f.name}>
          <TextField
            // sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
fullWidth
            size="small"
            label={f.label}
            name={f.name}
            value={formData[f.name]}
            onChange={handleChange}
            inputRef={(el) => (inputRefs.current[i] = el)}
          />
        </Grid>
      ))}
    </Grid> */}

      {/* ---------- ROW 2 : 5 COLUMNS ---------- */}
      {/* <Grid container spacing={2} mb={2}>
      {[
        { label: "Unit (TA)", name: "unit_ta" },
        { label: "Weight (kg)", name: "weight" },
        { label: "Purchase Price", name: "purchasePrice" },
        { label: "Profit %", name: "profitPercentage" },
        { label: "Selling Price", name: "sellingPrice" },
      ].map((f) => (
        <Grid item xs={12} sm={6} md={2.4}
 key={f.name}>
          <TextField
            // sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
fullWidth
            size="small"
            label={f.label}
            name={f.name}
            value={formData[f.name]}
            onChange={handleChange}
          />
        </Grid>
      ))}
    </Grid> */}

      {/* ---------- ROW 3 : 4 COLUMNS ---------- */}
      {/* <Grid container spacing={2} mb={2}>
      {[
        { label: "CGST %", name: "cgstPercentage" },
        { label: "SGST %", name: "sgstPercentage" },
        { label: "HSN Code", name: "hsnCode" },
        { label: "Product Code", name: "productCode" },
      ].map((f) => (
        <Grid item xs={12} sm={6} md={3} key={f.name}>
          <TextField
          //  sx={{ width: { xs: "100%", sm: 180, md: 210 } }}
fullWidth
            size="small"
            label={f.label}
            name={f.name}
            value={formData[f.name]}
            onChange={handleChange}
          />
        </Grid>
      ))}
    </Grid> */}

      <div className="w-full overflow-x-auto">
        <div
          className="
      grid gap-4
      grid-cols-1
      sm:grid-cols-[repeat(auto-fill,minmax(180px,1fr))]
      md:min-w-max
    "
        >
          {[
            { label: "Name (EN)", name: "name_en" },
            { label: "Name (TA)", name: "name_ta" },
            { label: "Category (EN)", name: "category_en" },
            { label: "Category (TA)", name: "category_ta" },
            { label: "Unit (EN)", name: "unit_en" },
            { label: "Unit (TA)", name: "unit_ta" },
            { label: "Weight (kg)", name: "weight" },
            { label: "Purchase Price", name: "purchasePrice" },
            { label: "Profit %", name: "profitPercentage" },
            { label: "Selling Price", name: "sellingPrice" },
            { label: "CGST %", name: "cgstPercentage" },
            { label: "SGST %", name: "sgstPercentage" },
            { label: "HSN Code", name: "hsnCode" },
            { label: "Product Code", name: "productCode" },
            { label: "Base Unit Type (G/ML/PCS)", name: "baseUnitType" },

            { label: "Fssai Number", name: "fssaiNumber" },
            { label: "Packed Date", name: "packedDate" },
            { label: "Use By Date", name: "useByDate" },
            { label: "MRP", name: "mrp" },
          ].map((f, i) => {
            //  ADD THIS BLOCK HERE
            if (f.name === "baseUnitType") {
              return (
                <TextField
                  key={f.name}
                  select
                  fullWidth
                  size="small"
                  label={f.label}
                  name={f.name}
                  value={formData[f.name]}
                  onChange={handleChange}
                  onKeyDown={(e) => handleKeyDown(e, i)}
                  inputRef={(el) => (inputRefs.current[i] = el)}
                >
                  <MenuItem value="G">G</MenuItem>
                  <MenuItem value="ML">ML</MenuItem>
                  <MenuItem value="PCS">PCS</MenuItem>
                </TextField>
              );
            }
            return (
              <TextField
                key={f.name}
                fullWidth
                size="small"
                label={f.label}
                name={f.name}
                type={
                  f.name === "packedDate" || f.name === "useByDate"
                    ? "date"
                    : "text"
                }
                value={formData[f.name]}
                onChange={handleChange}
                onKeyDown={(e) => handleKeyDown(e, i)} //  ADD THIS LINE
                InputLabelProps={
                  f.name === "packedDate" || f.name === "useByDate"
                    ? { shrink: true }
                    : undefined
                }
                inputRef={(el) => (inputRefs.current[i] = el)}
              />
            );
          })}
        </div>
      </div>

      {/* ---------- CHECKBOX ---------- */}
      <Grid container mb={2}>
        <Grid item xs={12}>
          <FormControlLabel
            control={
              <Checkbox
                checked={formData.allowRetail}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    allowRetail: e.target.checked,
                  }))
                }
              />
            }
            label="Enable Retail Variants (SKU)"
          />
        </Grid>
      </Grid>

      {/* ---------- BUTTONS ---------- */}
      <Grid container spacing={2}>
        <Grid item xs={12} sm={4} md={2}>
          <Button fullWidth variant="contained" onClick={handleSubmit}>
            {editProduct ? "Update" : "Add"}
          </Button>
        </Grid>

        {editProduct && (
          <Grid item xs={12} sm={4} md={2}>
            <Button
              fullWidth
              variant="outlined"
              color="warning"
              onClick={clearEdit}
            >
              Cancel
            </Button>
          </Grid>
        )}
      </Grid>

      {/* ---------- BARCODE ---------- */}
      {formData.productCode && (
        <Box textAlign="center" mt={2}>
          <svg ref={svgRef} />
        </Box>
      )}
    </Box>
  );
};

export default ProductForm;
