// import { useEffect, useMemo, useState } from "react";
// import { useParams } from "react-router-dom";
// import {
//   Box,
//   Paper,
//   Typography,
//   TextField,
//   MenuItem,
//   Button,
//   Table,
//   TableHead,
//   TableRow,
//   TableCell,
//   TableBody,
//   Pagination,
//   Stack,
// } from "@mui/material";

// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   Tooltip,
//   PieChart,
//   Pie,
//   Cell,
//   ResponsiveContainer,
//   AreaChart,
//   Area,
//   Legend,
// } from "recharts";

// import jsPDF from "jspdf";
// import autoTable from "jspdf-autotable";
// import * as XLSX from "xlsx";

// import customFetch from "../../utils/customFetch";
// import Breadcrumbs from "../../components/common/BreadCrumbs";
// import getLocalizedText from "../../utils/getLocalizedText";

// export default function SalesLedger() {
//   const { lang = "en" } = useParams();

//   // ---------------- STATE ----------------
//   const [ledger, setLedger] = useState([]);
//   const [customers, setCustomers] = useState([]);
//   const [customer, setCustomer] = useState("");
//   const [from, setFrom] = useState("");
//   const [to, setTo] = useState("");

//   const [monthly, setMonthly] = useState([]);
//   const [customerSummary, setCustomerSummary] = useState([]);
//   const [salesPayments, setSalesPayments] = useState([]);
//   const [outstanding, setOutstanding] = useState([]);

//   // pagination
//   const [page, setPage] = useState(1);
//   const rowsPerPage = 10;

//   const formatAmount = (num) => Number(num || 0).toFixed(2);

//   // ---------------- LABEL NORMALIZER (ENGLISH DEFAULT) ----------------
//   const normalizeLabel = (value) => {
//     if (!value) return "";

//     // already a normal string (like "bala", "karan")
//     if (typeof value === "string") {
//       // try to parse old stringified object
//       if (value.includes("en:")) {
//         try {
//           const fixed = value
//             .replace(/'/g, '"') // convert single quotes to double
//             .replace(/(\w+):/g, '"$1":'); // add quotes to keys

//           const parsed = JSON.parse(fixed);
//           return parsed.en || "";
//         } catch {
//           return value;
//         }
//       }
//       return value;
//     }

//     // proper object case
//     if (typeof value === "object") {
//       return value.en || "";
//     }

//     return "";
//   };

//   // ---------------- LOAD DATA ----------------
//   const loadData = async () => {
//     try {
//       const ledgerRes = await customFetch.get(
//         `/sales-ledger?customerId=${customer}&from=${from}&to=${to}`
//       );
//       setLedger(ledgerRes?.data?.data || []);

//       setMonthly(
//         (await customFetch.get("/sales-ledger/summary/monthly")).data?.data ||
//           []
//       );

//       setCustomerSummary(
//         (await customFetch.get("/sales-ledger/summary/customer")).data?.data ||
//           []
//       );

//       setSalesPayments(
//         (await customFetch.get("/sales-ledger/summary/payments")).data?.data ||
//           []
//       );

//       setOutstanding(
//         (await customFetch.get("/sales-ledger/summary/outstanding")).data
//           ?.data || []
//       );

//       setPage(1); // reset pagination on search
//     } catch (err) {
//       console.error("Sales Ledger load error:", err);
//     }
//   };

//   const loadCustomers = async () => {
//     try {
//       const res = await customFetch.get("/customer");
//       setCustomers(res?.data?.customers || []);
//     } catch (err) {
//       console.error("Load customers error:", err);
//     }
//   };

//   useEffect(() => {
//     loadData();
//     loadCustomers();
//   }, []);

//   // ---------------- CHART DATA ----------------
//   const top5CustomerSummary = useMemo(() => {
//     return [...customerSummary]
//       .sort((a, b) => (b.amount || 0) - (a.amount || 0))
//       .slice(0, 5)
//       .map((d) => ({
//         ...d,
//         customer: normalizeLabel(d.customer),
//       }));
//   }, [customerSummary]);

//   console.log(top5CustomerSummary);

//   const safeOutstandingData = useMemo(() => {
//     return [...outstanding]
//       .sort((a, b) => (b.pending || 0) - (a.pending || 0))
//       .slice(0, 5)
//       .map((d) => ({
//         ...d,
//         customer: normalizeLabel(d.customer),
//       }));
//   }, [outstanding]);

//   const pieColors = ["#4285F4", "#34A853", "#FBBC05", "#EA4335", "#9C27B0"];

//   // ---------------- PAGINATION ----------------
//   const totalPages = Math.ceil(ledger.length / rowsPerPage);

//   const paginatedLedger = useMemo(() => {
//     const start = (page - 1) * rowsPerPage;
//     return ledger.slice(start, start + rowsPerPage);
//   }, [ledger, page]);

//   // ---------------- EXPORT PDF ----------------
//   const exportPDF = () => {
//     const doc = new jsPDF();
//     doc.text("Sales Ledger Report", 14, 10);

//     const tableData = ledger.map((row) => [
//       new Date(row.date).toLocaleDateString(),
//       row.invoiceNumber || "-",
//       getLocalizedText(row.customer, lang),
//       formatAmount(row.billAmount),
//       formatAmount(row.paidAmount),
//       formatAmount(row.balanceAmount),
//     ]);

//     autoTable(doc, {
//       head: [["Date", "Invoice", "Customer", "Bill", "Paid", "Balance"]],
//       body: tableData,
//       startY: 20,
//     });

//     doc.save("SalesLedger.pdf");
//   };

//   // ---------------- EXPORT EXCEL ----------------
//   const exportExcel = () => {
//     const excelData = ledger.map((row) => ({
//       Date: new Date(row.date).toLocaleDateString(),
//       Invoice: row.invoiceNumber || "-",
//       Customer: getLocalizedText(row.customer, lang),
//       Bill: formatAmount(row.billAmount),
//       Paid: formatAmount(row.paidAmount),
//       Balance: formatAmount(row.balanceAmount),
//     }));

//     const worksheet = XLSX.utils.json_to_sheet(excelData);
//     const workbook = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(workbook, worksheet, "Sales Ledger");
//     XLSX.writeFile(workbook, "SalesLedger.xlsx");
//   };

//   return (
//     <Box sx={{ p: { xs: 1, md: 3 }, width: "100%" }}>
//       <Breadcrumbs />

//       <Typography variant="h5" fontWeight={600} mb={2}>
//         Sales Ledger
//       </Typography>

//       {/* FILTER */}
//       <Paper sx={{ p: 2, mb: 3, display: "flex", gap: 2, flexWrap: "wrap" }}>
//         <TextField
//           select
//           label="Customer"
//           value={customer}
//           onChange={(e) => setCustomer(e.target.value)}
//           sx={{ minWidth: 200 }}
//         >
//           <MenuItem value="">All Customers</MenuItem>
//           {customers.map((c) => (
//             <MenuItem key={c._id} value={c._id}>
//               {getLocalizedText(c.customerName, lang)}
//             </MenuItem>
//           ))}
//         </TextField>

//         <TextField
//           type="date"
//           label="From"
//           value={from}
//           onChange={(e) => setFrom(e.target.value)}
//           InputLabelProps={{ shrink: true }}
//         />

//         <TextField
//           type="date"
//           label="To"
//           value={to}
//           onChange={(e) => setTo(e.target.value)}
//           InputLabelProps={{ shrink: true }}
//         />

//         <Button variant="contained" onClick={loadData}>
//           Search
//         </Button>
//         <Button variant="outlined" onClick={exportPDF}>
//           PDF
//         </Button>
//         <Button variant="outlined" onClick={exportExcel}>
//           Excel
//         </Button>
//       </Paper>

//       {/* CHARTS */}
//       <Box
//         sx={{
//           display: "grid",
//           gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
//           gap: 2,
//           mb: 3,
//         }}
//       >
//         <Paper sx={{ p: 2 }}>
//           <Typography fontWeight={600}>Monthly Sales</Typography>
//           <ResponsiveContainer width="100%" height={250}>
//             <BarChart data={monthly}>
//               <XAxis dataKey="month" />
//               <YAxis />
//               <Tooltip />
//               <Bar dataKey="total" fill="#4285F4" />
//             </BarChart>
//           </ResponsiveContainer>
//         </Paper>

//         <Paper sx={{ p: 2 }}>
//           <Typography fontWeight={600}>Customer-wise Sales (Top 5)</Typography>
//           <ResponsiveContainer width="100%" height={250}>
//             <PieChart>
//               <Pie
//                 data={top5CustomerSummary}
//                 dataKey="amount"
//                 nameKey="customer"
//                 outerRadius={80}
//               >
//                 {top5CustomerSummary.map((_, i) => (
//                   <Cell key={i} fill={pieColors[i % pieColors.length]} />
//                 ))}
//               </Pie>
//               <Tooltip />
//               <Legend />
//             </PieChart>
//           </ResponsiveContainer>
//         </Paper>

//         <Paper sx={{ p: 2 }}>
//           <Typography fontWeight={600}>Sales vs Paid</Typography>
//           <ResponsiveContainer width="100%" height={250}>
//             <AreaChart data={salesPayments}>
//               <XAxis dataKey="month" />
//               <YAxis />
//               <Tooltip />
//               <Legend />
//               <Area dataKey="sales" stroke="#4285F4" fill="#4285F4" />
//               <Area dataKey="paid" stroke="#34A853" fill="#34A853" />
//               <Area dataKey="balance" stroke="#FBBC05" fill="#FBBC05" />
//             </AreaChart>
//           </ResponsiveContainer>
//         </Paper>

//         <Paper sx={{ p: 2 }}>
//           <Typography fontWeight={600}>Outstanding by Customer</Typography>
//           <ResponsiveContainer width="100%" height={250}>
//             <BarChart data={safeOutstandingData}>
//               <XAxis dataKey="customer" />
//               <YAxis />
//               <Tooltip />
//               <Bar dataKey="pending" fill="#EA4335" />
//             </BarChart>
//           </ResponsiveContainer>
//         </Paper>
//       </Box>

//       {/* TABLE */}
//       <Paper sx={{ p: 2 }}>
//         <Typography fontWeight={600} mb={2}>
//           Sales Ledger Entries
//         </Typography>

//         <Box sx={{ overflowX: "auto" }}>
//           <Table sx={{ minWidth: 850 }}>
//             <TableHead>
//               <TableRow>
//                 <TableCell>Date</TableCell>
//                 <TableCell>Invoice</TableCell>
//                 <TableCell>Customer</TableCell>
//                 <TableCell>Bill</TableCell>
//                 <TableCell>Paid</TableCell>
//                 <TableCell>Balance</TableCell>
//               </TableRow>
//             </TableHead>

//             <TableBody>
//               {paginatedLedger.map((row) => (
//                 <TableRow key={row.saleId}>
//                   <TableCell>
//                     {new Date(row.date).toLocaleDateString()}
//                   </TableCell>
//                   <TableCell>{row.invoiceNumber || "-"}</TableCell>
//                   <TableCell>{getLocalizedText(row.customer, lang)}</TableCell>
//                   <TableCell>₹{formatAmount(row.billAmount)}</TableCell>
//                   <TableCell>₹{formatAmount(row.paidAmount)}</TableCell>
//                   <TableCell>₹{formatAmount(row.balanceAmount)}</TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </Box>

//         {/* PAGINATION */}
//         {totalPages > 1 && (
//           <Stack alignItems="center" mt={2}>
//             <Pagination
//               count={totalPages}
//               page={page}
//               onChange={(_, value) => setPage(value)}
//               color="primary"
//               showFirstButton
//               showLastButton
//             />
//           </Stack>
//         )}
//       </Paper>
//     </Box>
//   );
// }


import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Box,
  Paper,
  Typography,
  TextField,
  MenuItem,
  Button,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Pagination,
  Stack,
} from "@mui/material";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  AreaChart,
  Area,
  Legend,
} from "recharts";

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

import customFetch from "../../utils/customFetch";
import Breadcrumbs from "../../components/common/BreadCrumbs";
import getLocalizedText from "../../utils/getLocalizedText";

export default function SalesLedger() {
  const { lang = "en" } = useParams();

  // ---------------- STATE ----------------
  const [ledger, setLedger] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [customer, setCustomer] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const [monthly, setMonthly] = useState([]);
  const [customerSummary, setCustomerSummary] = useState([]);
  const [salesPayments, setSalesPayments] = useState([]);
  const [outstanding, setOutstanding] = useState([]);

  // pagination
  const [page, setPage] = useState(1);
  const rowsPerPage = 10;

  const formatAmount = (num) => Number(num || 0).toFixed(2);

  // ---------------- LABEL NORMALIZER (ENGLISH DEFAULT) ----------------
  const normalizeLabel = (value) => {
    if (!value) return "";

    // already a normal string (like "bala", "karan")
    if (typeof value === "string") {
      // try to parse old stringified object
      if (value.includes("en:")) {
        try {
          const fixed = value
            .replace(/'/g, '"') // convert single quotes to double
            .replace(/(\w+):/g, '"$1":'); // add quotes to keys

          const parsed = JSON.parse(fixed);
          return parsed.en || "";
        } catch {
          return value;
        }
      }
      return value;
    }

    // proper object case
    if (typeof value === "object") {
      return value.en || "";
    }

    return "";
  };

  // ---------------- LOAD DATA ----------------
  const loadData = async () => {
    try {
      const ledgerRes = await customFetch.get(
        `/sales-ledger?customerId=${customer}&from=${from}&to=${to}`
      );
      setLedger(ledgerRes?.data?.data || []);

      setMonthly(
        (await customFetch.get("/sales-ledger/summary/monthly")).data?.data ||
          []
      );

      setCustomerSummary(
        (await customFetch.get("/sales-ledger/summary/customer")).data?.data ||
          []
      );

      setSalesPayments(
        (await customFetch.get("/sales-ledger/summary/payments")).data?.data ||
          []
      );

      setOutstanding(
        (await customFetch.get("/sales-ledger/summary/outstanding")).data
          ?.data || []
      );

      setPage(1); // reset pagination on search
    } catch (err) {
      console.error("Sales Ledger load error:", err);
    }
  };

  const loadCustomers = async () => {
    try {
      const res = await customFetch.get("/customer");
      setCustomers(res?.data?.customers || []);
    } catch (err) {
      console.error("Load customers error:", err);
    }
  };

  useEffect(() => {
    loadData();
    loadCustomers();
  }, []);

  // ---------------- CHART DATA ----------------
  const top5CustomerSummary = useMemo(() => {
    return [...customerSummary]
      .sort((a, b) => (b.amount || 0) - (a.amount || 0))
      .slice(0, 5)
      .map((d) => ({
        ...d,
        customer: normalizeLabel(d.customer),
      }));
  }, [customerSummary]);

  console.log(top5CustomerSummary);

  const safeOutstandingData = useMemo(() => {
    return [...outstanding]
      .sort((a, b) => (b.pending || 0) - (a.pending || 0))
      .slice(0, 5)
      .map((d) => ({
        ...d,
        customer: normalizeLabel(d.customer),
      }));
  }, [outstanding]);

  const pieColors = ["#4285F4", "#34A853", "#FBBC05", "#EA4335", "#9C27B0"];

  // ---------------- PAGINATION ----------------
  const totalPages = Math.ceil(ledger.length / rowsPerPage);

  const paginatedLedger = useMemo(() => {
    const start = (page - 1) * rowsPerPage;
    return ledger.slice(start, start + rowsPerPage);
  }, [ledger, page]);

  // ---------------- EXPORT PDF ----------------
  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text("Sales Ledger Report", 14, 10);

    const tableData = ledger.map((row) => [
      new Date(row.date).toLocaleDateString(),
      row.invoiceNumber || "-",
      getLocalizedText(row.customer, lang),
      formatAmount(row.billAmount),
      formatAmount(row.paidAmount),
      formatAmount(row.balanceAmount),
    ]);

    autoTable(doc, {
      head: [["Date", "Invoice", "Customer", "Bill", "Paid", "Balance"]],
      body: tableData,
      startY: 20,
    });

    doc.save("SalesLedger.pdf");
  };

  // ---------------- EXPORT EXCEL ----------------
  const exportExcel = () => {
    const excelData = ledger.map((row) => ({
      Date: new Date(row.date).toLocaleDateString(),
      Invoice: row.invoiceNumber || "-",
      Customer: getLocalizedText(row.customer, lang),
      Bill: formatAmount(row.billAmount),
      Paid: formatAmount(row.paidAmount),
      Balance: formatAmount(row.balanceAmount),
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sales Ledger");
    XLSX.writeFile(workbook, "SalesLedger.xlsx");
  };

  return (
    <Box sx={{ p: { xs: 1, md: 3 }, width: "100%" }}>
      {/* <Breadcrumbs /> */}

      <Typography variant="h5" fontWeight={600} mb={2}>
        Sales Ledger
      </Typography>

      {/* CHARTS */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
          gap: 2,
          mb: 3,
        }}
      >
        <Paper sx={{ p: 2 }}>
          <Typography fontWeight={600}>Monthly Sales</Typography>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthly}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="total" fill="#4285F4" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Typography fontWeight={600}>Customer-wise Sales (Top 5)</Typography>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={top5CustomerSummary}
                dataKey="amount"
                nameKey="customer"
                outerRadius={80}
              >
                {top5CustomerSummary.map((_, i) => (
                  <Cell key={i} fill={pieColors[i % pieColors.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Typography fontWeight={600}>Sales vs Paid</Typography>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={salesPayments}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area dataKey="sales" stroke="#4285F4" fill="#4285F4" />
              <Area dataKey="paid" stroke="#34A853" fill="#34A853" />
              <Area dataKey="balance" stroke="#FBBC05" fill="#FBBC05" />
            </AreaChart>
          </ResponsiveContainer>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Typography fontWeight={600}>Outstanding by Customer</Typography>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={safeOutstandingData}>
              <XAxis dataKey="customer" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="pending" fill="#EA4335" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Box>
      {/* FILTER */}
      <Paper sx={{ p: 2, mb: 3, display: "flex", gap: 2, flexWrap: "wrap" }}>
        <TextField
          select
          label="Customer"
          value={customer}
          onChange={(e) => setCustomer(e.target.value)}
          sx={{ minWidth: 200 }}
        >
          <MenuItem value="">All Customers</MenuItem>
          {customers.map((c) => (
            <MenuItem key={c._id} value={c._id}>
              {getLocalizedText(c.customerName, lang)}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          type="date"
          label="From"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
          InputLabelProps={{ shrink: true }}
        />

        <TextField
          type="date"
          label="To"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          InputLabelProps={{ shrink: true }}
        />

        <Button variant="contained" onClick={loadData}>
          Search
        </Button>
        <Button variant="outlined" onClick={exportPDF}>
          PDF
        </Button>
        <Button variant="outlined" onClick={exportExcel}>
          Excel
        </Button>
      </Paper>

      {/* TABLE */}
      <Paper sx={{ p: 2 }}>
        <Typography fontWeight={600} mb={2}>
          Sales Ledger Entries
        </Typography>

        <Box sx={{ overflowX: "auto" }}>
          <Table sx={{ minWidth: 850 }}>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Invoice</TableCell>
                <TableCell>Customer</TableCell>
                <TableCell>Bill</TableCell>
                <TableCell>Paid</TableCell>
                <TableCell>Balance</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {paginatedLedger.map((row) => (
                <TableRow key={row.saleId}>
                  <TableCell>
                    {new Date(row.date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>{row.invoiceNumber || "-"}</TableCell>
                  <TableCell>{getLocalizedText(row.customer, lang)}</TableCell>
                  <TableCell>₹{formatAmount(row.billAmount)}</TableCell>
                  <TableCell>₹{formatAmount(row.paidAmount)}</TableCell>
                  <TableCell>₹{formatAmount(row.balanceAmount)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>

        {/* PAGINATION */}
        {totalPages > 1 && (
          <Stack alignItems="center" mt={2}>
            <Pagination
              count={totalPages}
              page={page}
              onChange={(_, value) => setPage(value)}
              color="primary"
              showFirstButton
              showLastButton
            />
          </Stack>
        )}
      </Paper>
    </Box>
  );
}