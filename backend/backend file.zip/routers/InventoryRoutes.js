import express from "express";
import {
  adjustInventory,
  deleteInventory,
  getAllInventory,
  getAvailableStockForSales,
  getInventoryByProduct,
  getProductStock,
  getProductStockSummary,
} from "../controller/inventoryController.js";
import { authMiddleware } from "../middleware/authMiddleware.js";

const router = express.Router();

// Protect all inventory routes
router.use(authMiddleware);

router.get("/", getAllInventory);
router.get("/stock/sales", getAvailableStockForSales);
router.get("/:productId", getInventoryByProduct);
router.get("/summary/:productId", getProductStockSummary);
router.post("/adjust", adjustInventory);
router.get("/stock/:shopId/:productId", getProductStock);
router.delete("/:id", deleteInventory);

export default router;
