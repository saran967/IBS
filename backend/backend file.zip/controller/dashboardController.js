// controllers/dashboardController.js

import Sale from "../models/salesModel.js";
import Purchase from "../models/purchaseModel.js";
import Product from "../models/productModel.js";
import Customer from "../models/customerModel.js";
import StockTransfer from "../models/stockTransfer.js";
import getActiveFinancialYear from "../utils/getActiveFinancialYear.js";


export const getDashboardSummary = async (req, res) => {
  try {
        const activeFY = await getActiveFinancialYear();

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      todaySalesAgg,
      totalProducts,
      totalCustomers,
      lowStockProducts,
      recentSales,
      recentPurchases,
      pendingTransfers,
      topProducts,
    ] = await Promise.all([
      // TODAY SALES
      Sale.aggregate([
        { $match: { financialYearId: activeFY._id,createdAt: { $gte: today } } },
        { $group: { _id: null, total: { $sum: "$netTotal" } } },
      ]),

      Product.countDocuments(),
      Customer.countDocuments(),
      Product.countDocuments({ totalStock: { $lte: 5 } }),

      //  POPULATE CUSTOMER HERE
      Sale.find({ financialYearId: activeFY._id })
        .sort({ createdAt: -1 })
        .limit(5)
        .populate("customerId", "customerName")
        .lean(),

      //  POPULATE VENDOR HERE
      Purchase.find({ financialYearId: activeFY._id })
        .sort({ createdAt: -1 })
        .limit(5)
        .populate("vendorId", "name")
        .lean(),

      StockTransfer.countDocuments({  financialYearId: activeFY._id,status: { $ne: "approved" }, }),

      Product.find({ totalStock: { $gt: 0 } })
        .sort({ totalStock: 1 })
        .limit(10)
        .select("name totalStock productCode reorder")
        .lean(),
    ]);

    res.json({
      todaySales: todaySalesAgg[0]?.total || 0,
      totalProducts,
      totalCustomers,
      lowStockProducts,
      pendingTransfers,
      recentSales,
      recentPurchases,
      topProducts,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
