import React, { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Button,
  IconButton,
  CircularProgress,
  Typography,
} from "@mui/material";
import { Edit, Delete } from "@mui/icons-material";
import { toast } from "react-toastify";
import { useLanguage } from "../context/LanguageContext";
import customFetch from "../utils/customFetch";
import ProductPackForm from "../components/Admin/PacketForm";

const ProductPackList = () => {
  // Get language directly (en / ta / both)
  const lang = useLanguage();

  const [packs, setPacks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openForm, setOpenForm] = useState(false);
  const [selectedPack, setSelectedPack] = useState(null);

  // Utility to handle bilingual text
  const getLocalizedText = (value) => {
    if (!value) return "-";
    if (typeof value === "object") {
      if (lang === "both") return `${value.en || "-"} / ${value.ta || "-"}`;
      return value[lang] || value.en || value.ta || "-";
    }
    return value;
  };

  // Fetch all product packs
  const fetchPacks = async () => {
    setLoading(true);
    try {
      const res = await customFetch.get(`/product-packs?lang=${lang}`);
      setPacks(res.data.packs || []);
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Failed to fetch product packs"
      );
      setPacks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPacks();
  }, [lang]);

  const handleEdit = (pack) => {
    setSelectedPack(pack);
    setOpenForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this pack?")) return;
    try {
      await customFetch.delete(`/product-packs/${id}`);
      toast.success("Product pack deleted successfully");
      fetchPacks();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to delete pack");
    }
  };

  const handleCloseForm = () => {
    setSelectedPack(null);
    setOpenForm(false);
  };

  return (
    <div>
      <Typography variant="h5" sx={{ mb: 2 }}>
        Product Packs ({lang})
      </Typography>

      <Button
        variant="contained"
        color="primary"
        onClick={() => setOpenForm(true)}
        sx={{ mb: 2 }}
      >
        Add Product Pack
      </Button>

      {loading ? (
        <CircularProgress sx={{ display: "block", mx: "auto", mt: 5 }} />
      ) : packs.length === 0 ? (
        <Typography align="center">No product packs found.</Typography>
      ) : (
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Product</TableCell>
              <TableCell>Shop</TableCell>
              <TableCell>Pack Size</TableCell>
              <TableCell>Pack Count</TableCell>
              <TableCell>Total Weight</TableCell>
              <TableCell>Unit</TableCell>
              <TableCell>Price/Pack</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {packs.map((pack) => (
              <TableRow key={pack._id}>
                <TableCell>{getLocalizedText(pack.productId?.name)}</TableCell>
                <TableCell>{getLocalizedText(pack.shopId?.name)}</TableCell>
                <TableCell>{pack.packSize}</TableCell>
                <TableCell>{pack.packCount}</TableCell>
                <TableCell>{pack.totalWeight}</TableCell>
                <TableCell>{getLocalizedText(pack.unit)}</TableCell>
                <TableCell>{pack.pricePerPack}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleEdit(pack)} color="primary">
                    <Edit />
                  </IconButton>
                  <IconButton
                    onClick={() => handleDelete(pack._id)}
                    color="secondary"
                  >
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {openForm && (
        <ProductPackForm
          open={openForm}
          onClose={handleCloseForm}
          refreshList={fetchPacks}
          pack={selectedPack}
        />
      )}
    </div>
  );
};

export default ProductPackList;
