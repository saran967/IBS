import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableContainer,
  Switch,
  IconButton,
  Box,
  Tooltip,
  Checkbox,
  TextField,
  Button,
  MenuItem,
  Pagination,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Autocomplete,
  Card,
  CardContent,
} from "@mui/material";

import { Delete, Edit, History, Print } from "@mui/icons-material";
import JsBarcode from "jsbarcode";
import SKUModal from "./SkuModel";
import customFetch from "../../utils/customFetch.js";
import React, { useRef, useEffect, useState, useMemo } from "react";

// --------------------------------------------------
// BARCODE COMPONENT
// --------------------------------------------------
const BarcodeRenderer = ({ code, id }) => {
  const ref = useRef(null);

  useEffect(() => {
    if (!code || !ref.current) return;

    ref.current.innerHTML = "";
    JsBarcode(ref.current, code, {
      format: "CODE128",
      width: 2.2,
      height: 35,
      displayValue: true,
      fontSize: 10,
      margin: 2,
    });
  }, [code, id]);

  return <svg ref={ref} />;
};

// --------------------------------------------------
// MAIN PRODUCT TABLE
// --------------------------------------------------
const ProductTable = ({
  lang,
  products,
  onToggleDelivery,
  onEdit,
  onDelete,
  onPriceHistory,
  getField,
  page: externalPage,
  totalPages: externalTotalPages,
  onPageChange,
  pageSize,
  onEditComplete,
  categories,
  selectedCategory,
  setSelectedCategory,
  toggleCategory,
}) => {
  const PAGE_LIMIT = pageSize || 10;
  const [selected, setSelected] = useState({});
  const [searchText, setSearchText] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [page, setPage] = useState(1);
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  // SKU Modal
  const [skuModalOpen, setSkuModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailsProduct, setDetailsProduct] = useState(null);

  const [lastEditedProductId, setLastEditedProductId] = useState(null);

  const openDetails = (product) => {
    setDetailsProduct(product);
    setDetailsOpen(true);
  };

  const closeDetails = () => {
    setDetailsOpen(false);
    setDetailsProduct(null);
  };

  const openSKUModal = (product) => {
    setLastEditedProductId(product._id);
    setSelectedProduct(product);
    setSkuModalOpen(true);
  };

  const stop = (e) => e.stopPropagation();

  const toggleSelect = (id) => {
    setSelected((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // ----------------------------------------
  // FILTER PRODUCTS
  // --------------------------------------------------

  const makeCategoryKey = (c) => c?.en || "";

  const baseProducts = isSearching ? searchResults : products;
  const filteredProducts = baseProducts.filter((p) => {
    const text = searchText.toLowerCase();

    const matchesSearch =
      getField(p.name).toLowerCase().includes(text) ||
      (p.productCode || "").toLowerCase().includes(text);

    const matchesCategory =
      categoryFilter === "ALL" || p.category?.en === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  // newest first

  const sortByNewest = (list) =>
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt || b.updatedAt || 0) -
        new Date(a.createdAt || a.updatedAt || 0),
    );

  const sortedProducts = useMemo(
    () => sortByNewest(filteredProducts),
    [filteredProducts],
  );

  const searchProductsAPI = async (text, category) => {
    if (!text && (!category || category === "ALL")) {
      setIsSearching(false);
      setSearchResults([]);
      return;
    }

    setIsSearching(true);

    const params = new URLSearchParams();

    if (text) {
      params.append("q", text.trim());
    }

    if (category && category !== "ALL") {
      params.append("category", category); //  string (category.en)
    }

    console.log("Search Params:", params.toString());

    const res = await customFetch.get(
      `/product/searchByCategory?${params.toString()}`,
    );

    setSearchResults(res.data.products || []);
  };

  const usingExternalPagination = Boolean(onPageChange) && !isSearching;

  const currentPage = usingExternalPagination ? externalPage || 1 : page;
  const totalPages =
    usingExternalPagination && externalTotalPages
      ? externalTotalPages
      : Math.max(1, Math.ceil(sortedProducts.length / PAGE_LIMIT));

  const currentPageData = useMemo(() => {
    if (usingExternalPagination) return sortedProducts;
    const start = (currentPage - 1) * PAGE_LIMIT;
    return sortedProducts.slice(start, start + PAGE_LIMIT);
  }, [sortedProducts, usingExternalPagination, currentPage]);

  useEffect(() => {
    searchProductsAPI(searchText, categoryFilter);
  }, [searchText, categoryFilter]);

  // --------------------------------------------------
  // SELECT ALL
  // --------------------------------------------------
  const allSelected =
    currentPageData.length > 0 && currentPageData.every((p) => selected[p._id]);

  const someSelected =
    currentPageData.some((p) => selected[p._id]) && !allSelected;

  const toggleSelectAll = () => {
    if (allSelected) {
      const newState = { ...selected };
      currentPageData.forEach((p) => delete newState[p._id]);
      setSelected(newState);
    } else {
      const newState = { ...selected };
      currentPageData.forEach((p) => (newState[p._id] = true));
      setSelected(newState);
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB");
  };

  const cellSx = {
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  };

  // --------------------------------------------------
  // PRINT SINGLE
  // --------------------------------------------------
  const handlePrint = (p) => {
    const svg = document.getElementById(`barcode-${p._id}`)?.outerHTML;

    const win = window.open("", "_blank");

    win.document.write(`
      <html>
      <head>
       <style>
  @page { size: 48mm auto; margin: 2mm; }

  body {
    width: 48mm;
    margin: 0;
    padding: 0;
    font-family: Arial;
    text-align: center;
  }

  .label {
    width: 100%;
  }

  .name {
    font-size: 12px;
    font-weight: bold;
    margin-bottom: 2px;
  }

  .barcode svg {
    width: 100%;
    height: 48px;
  }

  .code {
    font-size: 10px;
    margin: 2px 0;
  }

  .row {
    font-size: 10px;
    text-align: center;
    padding-left: 2px;
    margin-top: 5px;
  }

  .divider {
    border-top: 1px dashed #000;
    margin: 4px 0;
  }

  .fssai {
    font-size: 10px;
    text-align: center;
  }
</style>

      </head>
    <body>
  <div class="label">
    <div class="name">${getField(p.name)}</div>

    <div class="barcode">
      ${svg || ""}
    </div>

    <div class="row">Packed date : ${formatDate(p.packedDate)}</div>
    <div class="row">Use by date : ${formatDate(p.useByDate)}</div>
    <div class="row">MRP : ₹${p.mrp}</div>

    ${
      p.fssaiNumber
        ? `
      <div class="divider"></div>
      <div class="fssai">FSSAI No : ${p.fssaiNumber}</div>
    `
        : ""
    }
  </div>

  <script>
    window.onload = () => window.print();
  </script>
</body>


      </html>
    `);

    win.document.close();
  };

  // --------------------------------------------------
  // PRINT ALL SELECTED
  // --------------------------------------------------
  const handlePrintAll = () => {
    const items = products.filter((p) => selected[p._id]);

    if (items.length === 0) {
      alert("Select at least one product to print!");
      return;
    }

    const win = window.open("", "_blank");

    win.document.write(`
    <html>
    <head>
      <style>
        @page { size: 48mm auto; margin: 2mm; }

        body {
          width: 48mm;
          margin: 0;
          padding: 0;
          font-family: Arial;
          text-align: center;
        }

        .label {
          width: 100%;
          page-break-inside: avoid;
          margin-bottom: 6px;
        }

        .name {
          font-size: 12px;
          font-weight: bold;
          margin-bottom: 2px;
        }

        .barcode svg {
          width: 100%;
          height: 48px;
        }

        .row {
          font-size: 10px;
          margin-top: 2px;
        }

        .divider {
          border-top: 1px dashed #000;
          margin: 4px 0;
        }

        .fssai {
          font-size: 10px;
        }
      </style>
    </head>
    <body>
  `);

    items.forEach((p) => {
      const svg = document.getElementById(`barcode-${p._id}`)?.outerHTML || "";

      win.document.write(`
      <div class="label">
        <div class="name">${getField(p.name)}</div>

        <div class="barcode">
          ${svg}
        </div>

        <div class="row">Packed date : ${formatDate(p.packedDate)}</div>
        <div class="row">Use by date : ${formatDate(p.useByDate)}</div>
        <div class="row">MRP : ₹${p.mrp}</div>

        ${
          p.fssaiNumber
            ? `
          <div class="divider"></div>
          <div class="fssai">FSSAI No : ${p.fssaiNumber}</div>
        `
            : ""
        }
      </div>
    `);
    });

    // --------------------------------------------------
    // PRICE HISTORY FOR SELECTED PRODUCTS
    // --------------------------------------------------
    // --------------------------------------------------
    // PRICE HISTORY FOR SELECTED PRODUCTS
    // --------------------------------------------------

    win.document.write(`
      <script>
        window.onload = () => window.print();
      </script>
    </body>
    </html>
  `);

    win.document.close();
  };

  // --------------------------------------------------
  // PRICE HISTORY FOR SELECTED PRODUCTS (CORRECT PLACE)
  // --------------------------------------------------
  const handlePriceHistorySelected = async () => {
    const selectedIds = Object.keys(selected).filter((id) => selected[id]);

    if (selectedIds.length === 0) {
      alert("Select at least one product to download price history!");
      return;
    }

    try {
      const res = await customFetch.post("/product/price-history/selected", {
        productIds: selectedIds,
      });

      if (!res.data?.history || res.data.history.length === 0) {
        alert("No price history found for selected products");
        return;
      }

      import("../../pages/exportAllHistoryPDF.js").then(
        ({ default: exportAllHistoryPDF }) => {
          exportAllHistoryPDF(res.data.history);
        },
      );
    } catch (err) {
      console.error(err);
      alert("Failed to download price history");
    }
  };

  // --------------------------------------------------
  // HEADERS
  // --------------------------------------------------
  const finalHeaders = {
    name: lang === "ta" ? "பெயர்" : "Name",
    category: lang === "ta" ? "வகை" : "Category",
    unit: lang === "ta" ? "அளவு" : "Unit",
    weight: lang === "ta" ? "எடை" : "Weight",
    purchase: lang === "ta" ? "கொள்முதல் விலை" : "Purchase",
    selling: lang === "ta" ? "விற்பனை விலை" : "Selling Price",
    code: lang === "ta" ? "குறியீடு" : "Code",
    barcode: lang === "ta" ? "பார்கோட்" : "Barcode",
    sku: "SKU",
    details: lang === "ta" ? "விவரம்" : "Details",
    delivery: lang === "ta" ? "விநியோகம்" : "Delivery",

    action: lang === "ta" ? "செயல்" : "Action",
  };

  // --------------------------------------------------
  // RENDER
  // --------------------------------------------------
  return (
    <Box sx={{ width: "100%", p: 1 }}>
      {/* FILTER BAR */}
      <Box
        sx={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          gap: 1.5,
          mb: 2,
        }}
      >
        {/* CATEGORY FILTER */}
        <Autocomplete
          options={categories}
          getOptionLabel={(o) => o.en}
          value={selectedCategory}
          onChange={(e, val) => setSelectedCategory(val)}
          renderInput={(params) => (
            <TextField {...params} label="Category" size="small" />
          )}
          sx={{ width: { xs: "100%", sm: 220 } }}
        />
        {selectedCategory && (
          <Card sx={{ minWidth: 180 }}>
            <CardContent
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                p: 1,
              }}
            >
              <Typography variant="body2">{selectedCategory.en}</Typography>
              <Switch
                checked={selectedCategory.enabled}
                onChange={() => toggleCategory(selectedCategory)}
                size="small"
              />
            </CardContent>
          </Card>
        )}
        <TextField
          size="small"
          label="Search by Name / Code"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          sx={{ width: { xs: "100%", sm: 250 } }}
        />
        <TextField
          select
          size="small"
          label="Category"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          sx={{ width: { xs: "100%", sm: 200 } }}
        >
          <MenuItem value="ALL">ALL</MenuItem>

          {categories.map((c) => (
            <MenuItem key={c.en} value={c.en}>
              {lang === "ta" ? c.ta : c.en}
            </MenuItem>
          ))}
        </TextField>
        {/* SELECT ALL */}
        <Checkbox
          checked={allSelected}
          indeterminate={someSelected}
          onChange={toggleSelectAll}
        />
        Select All
        <Button
          variant="contained"
          color="success"
          size="small"
          startIcon={<Print />}
          onClick={handlePrintAll}
        >
          Print Selected
        </Button>
        <Button
          variant="contained"
          color="primary"
          size="small"
          startIcon={<History />}
          onClick={handlePriceHistorySelected}
        >
          Price History
        </Button>
      </Box>

      {/* TABLE */}
      <Box sx={{ width: "100%" }}>
        <TableContainer
          sx={{
            overflowX: "auto",
            maxWidth: "100%",
          }}
        >
          <Table
            size="small"
            sx={{
              minWidth: 1200,
              tableLayout: "fixed",
              whiteSpace: "nowrap",
              display: "block",
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell>
                  <Checkbox
                    checked={allSelected}
                    indeterminate={someSelected}
                    onChange={toggleSelectAll}
                    size="small"
                  />
                </TableCell>

                {Object.values(finalHeaders).map((h) => (
                  <TableCell key={h}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {sortedProducts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={12} align="center">
                    {lang === "ta" ? "பொருட்கள் இல்லை" : "No products"}
                  </TableCell>
                </TableRow>
              ) : (
                currentPageData.map((p) => (
                  <TableRow
                    id={`product-row-${p._id}`}
                    key={p._id}
                    hover
                    sx={{ cursor: "pointer" }}
                    onClick={() => toggleSelect(p._id)}
                  >
                    <TableCell onClick={stop}>
                      <Checkbox
                        checked={selected[p._id] || false}
                        onChange={() => toggleSelect(p._id)}
                        size="small"
                      />
                    </TableCell>

                    {/* FIXED CATEGORY COLOR LOGIC */}
                    <TableCell sx={{ ...cellSx, width: 200 }}>
                      {getField(p.name)}
                    </TableCell>
                    <TableCell sx={{ ...cellSx, width: 140 }}>
                      {getField(p.category)}
                    </TableCell>

                    <TableCell>{getField(p.unit)}</TableCell>

                    <TableCell>
                      {p.weight != null
                        ? p.baseUnitType === "G" || p.baseUnitType === "ML"
                          ? (p.weight / 1000).toString()
                          : p.weight
                        : "-"}
                    </TableCell>
                    <TableCell>₹{p.purchasePrice ?? 0}</TableCell>
                    {/* <TableCell>{p.profitPercentage ?? 0}%</TableCell>
                  <TableCell>{p.cgstPercentage ?? 0}%</TableCell>
                  <TableCell>{p.sgstPercentage ?? 0}%</TableCell> */}

                    <TableCell>
                      ₹
                      {(
                        Number(p.sellingPrice || 0) +
                        Number(p.sellingPrice || 0) *
                          ((Number(p.cgstPercentage || 0) +
                            Number(p.sgstPercentage || 0)) /
                            100)
                      ).toFixed(2)}
                    </TableCell>

                    <TableCell>{p.productCode}</TableCell>
                    {/* <TableCell>{p.hsnCode || "—"}</TableCell> */}

                    <TableCell onClick={stop}>
                      {p.productCode ? (
                        <div id={`barcode-${p._id}`}>
                          <BarcodeRenderer code={p.productCode} id={p._id} />
                        </div>
                      ) : (
                        "-"
                      )}
                    </TableCell>

                    {/* SKU BUTTON */}
                    <TableCell>
                      <Tooltip
                        title={
                          p.allowRetail
                            ? "Manage Retail SKUs"
                            : "Retail SKUs are disabled for this product"
                        }
                      >
                        <span>
                          <Button
                            size="small"
                            variant="outlined"
                            disabled={!p.allowRetail}
                            onClick={() => p.allowRetail && openSKUModal(p)}
                          >
                            Manage
                          </Button>
                        </span>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => openDetails(p)}
                      >
                        View
                      </Button>
                    </TableCell>

                    <TableCell align="center" onClick={stop}>
                      <Switch
                        checked={p.enableDelivery ?? true}
                        onChange={() =>
                          onToggleDelivery(p._id, p.enableDelivery)
                        }
                        size="small"
                        color="success"
                      />
                    </TableCell>

                    <TableCell
                      onClick={stop}
                      sx={{
                        width: 140,
                        position: "sticky",
                        right: 0,
                        background: "#fff",
                        zIndex: 2,
                      }}
                    >
                      <Tooltip title="Edit">
                        <IconButton
                          size="small"
                          onClick={() => onEdit(p)}
                          color="primary"
                        >
                          <Edit fontSize="small" />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="History">
                        <IconButton
                          size="small"
                          onClick={() => onPriceHistory(p._id)}
                          color="secondary"
                        >
                          <History fontSize="small" />
                        </IconButton>
                      </Tooltip>

                      <Tooltip title="Print">
                        <IconButton
                          size="small"
                          onClick={() => handlePrint(p)}
                          color="success"
                        >
                          <Print fontSize="small" />
                        </IconButton>
                      </Tooltip>

                      {/* <Tooltip title="Delete">
                      <IconButton
                        size="small"
                        onClick={() => onDelete(p._id)}
                        color="error"
                      >
                        <Delete fontSize="small" />
                      </IconButton>
                    </Tooltip> */}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
      {skuModalOpen && (
        <SKUModal
          open={skuModalOpen}
          onClose={() => {
            setSkuModalOpen(false);

            if (lastEditedProductId) {
              onEditComplete?.(lastEditedProductId);
            }
          }}
          product={selectedProduct}
        />
      )}

      <Dialog open={detailsOpen} onClose={closeDetails} maxWidth="xs" fullWidth>
        <DialogTitle>
          {lang === "ta" ? "பொருள் விவரம்" : "Product Details"}
        </DialogTitle>

        <DialogContent dividers>
          {detailsProduct && (
            <Box display="flex" flexDirection="column" gap={1}>
              <Typography>
                <b>Profit %:</b> {detailsProduct.profitPercentage ?? 0}%
              </Typography>

              <Typography>
                <b>CGST %:</b> {detailsProduct.cgstPercentage ?? 0}%
              </Typography>

              <Typography>
                <b>SGST %:</b> {detailsProduct.sgstPercentage ?? 0}%
              </Typography>

              <Typography>
                <b>HSN Code:</b> {detailsProduct.hsnCode || "—"}
              </Typography>
            </Box>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={closeDetails}>Close</Button>
        </DialogActions>
      </Dialog>

      <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={(e, value) =>
            usingExternalPagination ? onPageChange?.(value) : setPage(value)
          }
          color="primary"
        />
      </Box>
    </Box>
  );
};

export default ProductTable;
